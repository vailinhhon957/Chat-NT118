package com.example.chat_compose.push

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class MyFirebaseMessagingService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        // Khi token thay đổi thì cập nhật lại lên Firestore
        val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
        val data = mapOf("fcmToken" to token)
        FirebaseFirestore.getInstance().collection("users").document(uid)
            .set(data, SetOptions.merge())
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)

        // Xử lý tin nhắn đến khi app đang chạy (foreground) hoặc background
        val data = remoteMessage.data
        if (data.isNotEmpty()) {
            val partnerId = data["partnerId"] ?: ""
            val title = data["title"] ?: "Tin nhắn mới"
            val body = data["body"] ?: ""

            // Hiện thông báo
            NotificationHelper.showMessage(
                context = applicationContext,
                partnerId = partnerId,
                title = title,
                body = body
            )
        }
    }

}