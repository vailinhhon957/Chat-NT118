package com.example.chat_compose.push

object PushActions {
    const val ACTION_NEW_MESSAGE = "com.example.chat_compose.ACTION_NEW_MESSAGE"

    const val EXTRA_FROM_ID = "fromId"
    const val EXTRA_FROM_NAME = "fromName"
    const val EXTRA_TEXT = "text"
}