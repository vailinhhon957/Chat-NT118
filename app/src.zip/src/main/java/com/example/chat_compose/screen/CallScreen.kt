package com.example.chat_compose.screen

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.chat_compose.call.WebRtcClient
import com.example.chat_compose.data.CallRepository
import kotlinx.coroutines.launch
import org.webrtc.RendererCommon
import org.webrtc.SurfaceViewRenderer

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CallScreen(
    partnerId: String,
    partnerName: String,
    isCaller: Boolean,
    callId: String,
    callType: String, // "audio" | "video"
    onBack: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val repo = remember { CallRepository() }
    val scope = rememberCoroutineScope()

    var status by remember { mutableStateOf("ringing") } // ringing | accepted | ended
    var startedWebRtc by remember { mutableStateOf(false) }

    // tránh popBackStack 2 lần (gây trắng màn hình / crash điều hướng)
    var didGoBack by remember { mutableStateOf(false) }
    val goBackOnce: () -> Unit = {
        if (!didGoBack) {
            didGoBack = true
            onBack()
        }
    }

    // WebRTC client (đặt trước permLauncher vì callback cần dùng webRtc)
    val webRtc = remember(callId) {
        WebRtcClient(
            context = context,
            repo = repo,
            scope = scope
        )
    }

    // permissions / accept flow
    var pendingAccept by remember { mutableStateOf(false) }

    // runtime permissions
    val requiredPerms = remember(callType) {
        if (callType == "video") {
            arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA)
        } else {
            arrayOf(Manifest.permission.RECORD_AUDIO)
        }
    }
    var permsGranted by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        permsGranted = requiredPerms.all { result[it] == true }

        // Nếu trước đó user bấm "Nhận" nhưng chưa có quyền -> cấp quyền xong mới accept + startCallee
        if (permsGranted && pendingAccept) {
            pendingAccept = false
            scope.launch {
                repo.acceptCall(callId)
                startedWebRtc = true
                runCatching { webRtc.startCallee(callId, callType == "video") }
            }
        }
    }

    // ===== Video renderers (Compose <-> SurfaceViewRenderer) =====
    val withVideo = callType == "video"
    val eglCtx = remember(callId, withVideo) {
        if (withVideo) webRtc.ensureEglContext() else null
    }

    var localRenderer by remember(callId) { mutableStateOf<SurfaceViewRenderer?>(null) }
    var remoteRenderer by remember(callId) { mutableStateOf<SurfaceViewRenderer?>(null) }

    // Khi renderer được tạo / thay đổi -> set vào WebRtcClient
    LaunchedEffect(localRenderer, remoteRenderer) {
        if (withVideo) {
            webRtc.setVideoRenderers(localRenderer, remoteRenderer)
        }
    }

    // Listen call doc (status)
    LaunchedEffect(callId) {
        repo.listenCallDoc(callId).collect { data ->
            val s = data["status"] as? String ?: return@collect
            status = s
            if (s == "ended") {
                runCatching { webRtc.stop() }
                goBackOnce()
            }
        }
    }

    // Start WebRTC đúng thời điểm:
    // - Caller: khi status == accepted -> startCaller()
    // - Callee: khi bấm Accept -> startCallee()
    LaunchedEffect(status, permsGranted) {
        if (!permsGranted) return@LaunchedEffect
        if (startedWebRtc) return@LaunchedEffect

        if (isCaller && status == "accepted") {
            startedWebRtc = true
            runCatching { webRtc.startCaller(callId, callType == "video") }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            // release theo thứ tự: detach sinks -> release renderer -> stop/dispose
            runCatching { webRtc.clearVideoRenderers() }
            runCatching { localRenderer?.release() }
            runCatching { remoteRenderer?.release() }
            localRenderer = null
            remoteRenderer = null
            runCatching { webRtc.dispose() }
        }
    }

    // UI
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1220), Color(0xFF111827))
                )
            )
            .systemBarsPadding()
    ) {
        // ====== VIDEO UI: remote full, local PiP ======
        if (withVideo && status == "accepted") {
            Box(Modifier.fillMaxSize()) {
                // Remote video
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).apply {
                            init(eglCtx, null)
                            setEnableHardwareScaler(true)
                            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                            setMirror(false)
                            remoteRenderer = this
                        }
                    }
                )

                // Local video (PiP)
                AndroidView(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(14.dp)
                        .size(width = 120.dp, height = 170.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
                    factory = { ctx ->
                        SurfaceViewRenderer(ctx).apply {
                            init(eglCtx, null)
                            setEnableHardwareScaler(true)
                            setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FILL)
                            setMirror(true)
                            localRenderer = this
                        }
                    }
                )

                // Overlay controls bottom
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (!permsGranted) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.Black.copy(alpha = 0.35f)),
                            shape = RoundedCornerShape(18.dp)
                        ) {
                            Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "Cần quyền Micro + Camera để gọi video",
                                    color = Color.White
                                )
                                Spacer(Modifier.height(10.dp))
                                Button(
                                    onClick = { permLauncher.launch(requiredPerms) },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Cho phép") }
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }

                    Button(
                        onClick = {
                            scope.launch {
                                repo.endCall(callId)
                                goBackOnce()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Kết thúc")
                    }

                    Spacer(Modifier.height(16.dp))
                }
            }
            return@Box
        }

        // ====== AUDIO / RINGING UI (giữ như bạn đang có) ======
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(14.dp))

            val initials = (partnerName.ifBlank { partnerId }).trim().firstOrNull()?.uppercase() ?: "U"
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.08f)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = initials,
                    style = MaterialTheme.typography.headlineLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(Modifier.height(14.dp))

            Text(
                text = partnerName.ifBlank { partnerId },
                color = Color.White,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(Modifier.height(6.dp))

            Text(
                text = when (status) {
                    "ringing" -> if (isCaller) "Đang gọi..." else "Cuộc gọi đến..."
                    "accepted" -> if (callType == "video") "Đang gọi video" else "Đang gọi thoại"
                    else -> "Kết thúc"
                },
                color = Color.White.copy(alpha = 0.7f),
                style = MaterialTheme.typography.bodyMedium
            )

            Spacer(Modifier.height(18.dp))

            if (!permsGranted) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.06f)),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Column(Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (callType == "video")
                                "Cần quyền Micro + Camera để gọi video"
                            else
                                "Cần quyền Micro để gọi thoại",
                            color = Color.White
                        )
                        Spacer(Modifier.height(10.dp))
                        Button(
                            onClick = { permLauncher.launch(requiredPerms) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Cho phép") }
                    }
                }
                Spacer(Modifier.height(14.dp))
            }

            Spacer(Modifier.weight(1f))

            when (status) {
                "ringing" -> {
                    if (isCaller) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            FilledTonalButton(
                                onClick = { permLauncher.launch(requiredPerms) },
                                modifier = Modifier.weight(1f),
                                enabled = !permsGranted
                            ) { Text("Xin quyền") }

                            Button(
                                onClick = {
                                    scope.launch {
                                        repo.endCall(callId)
                                        goBackOnce()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                            ) {
                                Icon(Icons.Filled.CallEnd, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Hủy")
                            }
                        }
                    } else {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Button(
                                onClick = {
                                    scope.launch {
                                        if (!permsGranted) {
                                            pendingAccept = true
                                            permLauncher.launch(requiredPerms)
                                            return@launch
                                        }

                                        repo.acceptCall(callId)
                                        startedWebRtc = true
                                        runCatching { webRtc.startCallee(callId, callType == "video") }
                                    }
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    if (callType == "video") Icons.Filled.Videocam else Icons.Filled.Mic,
                                    contentDescription = null
                                )
                                Spacer(Modifier.width(6.dp))
                                Text("Nhận")
                            }

                            Button(
                                onClick = {
                                    scope.launch {
                                        repo.rejectCall(callId)
                                        goBackOnce()
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                            ) {
                                Icon(Icons.Filled.CallEnd, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text("Từ chối")
                            }
                        }
                    }
                }

                "accepted" -> {
                    Button(
                        onClick = {
                            scope.launch {
                                repo.endCall(callId)
                                goBackOnce()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))
                    ) {
                        Icon(Icons.Filled.CallEnd, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Kết thúc")
                    }
                }

                else -> {
                    Button(
                        onClick = onBack,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Đóng") }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }
}
