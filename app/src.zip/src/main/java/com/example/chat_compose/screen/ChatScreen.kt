package com.example.chat_compose.screen

import android.graphics.BitmapFactory
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.chat_compose.ChatViewModel
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.launch
import java.util.Date
import kotlin.math.abs
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(
    viewModel: ChatViewModel,
    partnerId: String,
    onBack: () -> Unit,
    onStartCall: (String, String, String) -> Unit // (partnerId, partnerName, callType)
) {
    val messages = viewModel.messages
    val partner = viewModel.partnerUser
    val replyingTo = viewModel.replyingTo
    val myId = FirebaseAuth.getInstance().currentUser?.uid

    var text by remember { mutableStateOf("") }
    var reactionTargetId by remember { mutableStateOf<String?>(null) }

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val pickImageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
            if (bytes != null) viewModel.sendImageMessage(partnerId, bytes)
        }
    }

    // ===== ALWAYS AUTO-SCROLL TO LAST MESSAGE =====
    val listState = rememberLazyListState()

    // Khi mới vào chat mà đã có sẵn message -> kéo xuống cuối ngay
    LaunchedEffect(partnerId) {
        if (messages.isNotEmpty()) {
            listState.scrollToItem(messages.size - 1)
        }
    }

    // Mỗi lần messages thay đổi -> luôn animate xuống cuối
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val reactionEmojis = remember { listOf("👍", "❤️", "😂", "😮", "😢", "😡") }

    Box(modifier = Modifier.fillMaxSize()) {

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF4F5BD5), Color(0xFF962FBF), Color(0xFF4F5BD5))
                    )
                )
                .clickable(
                    indication = null,
                    interactionSource = remember { MutableInteractionSource() }
                ) { reactionTargetId = null }
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.25f))
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .systemBarsPadding()
        ) {

            // ===== TOP BAR =====
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White
                    )
                }

                AvatarBubble(
                    initialsName = partner?.displayName,
                    email = partner?.email,
                    avatarBytes = partner?.avatarBytes,
                    size = 36.dp
                )

                Spacer(Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = partner?.displayName ?: "Đoạn chat",
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )

                    val statusText = remember(partner?.isOnline, partner?.lastSeen) {
                        when {
                            partner?.isOnline == true -> "Đang hoạt động"
                            partner?.lastSeen != null -> {
                                val diffMillis = Date().time - partner.lastSeen.time
                                val diffMinutes = (diffMillis / 60000L).coerceAtLeast(1)
                                if (diffMinutes < 60) "Hoạt động $diffMinutes phút trước"
                                else "Hoạt động ${diffMinutes / 60} giờ trước"
                            }
                            else -> "Không hoạt động"
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (partner?.isOnline == true) Color(0xFF4CAF50) else Color.LightGray)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = statusText,
                            color = Color.White.copy(alpha = 0.7f),
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                val nameForCall = partner?.displayName ?: partner?.email ?: "Người dùng"

                IconButton(onClick = { onStartCall(partnerId, nameForCall, "audio") }) {
                    Icon(Icons.Filled.Call, contentDescription = "Audio call", tint = Color.White)
                }

                IconButton(onClick = { onStartCall(partnerId, nameForCall, "video") }) {
                    Icon(Icons.Filled.Videocam, contentDescription = "Video call", tint = Color.White)
                }
            }

            // ===== MESSAGE LIST =====
            val density = LocalDensity.current
            val maxDragPx = with(density) { 80.dp.toPx() }

            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                reverseLayout = false,
                contentPadding = PaddingValues(vertical = 8.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isMe = msg.fromId == myId
                    var dragOffset by remember(msg.id) { mutableStateOf(0f) }

                    val reactionCounts = remember(msg.reactions) {
                        msg.reactions.values.groupingBy { it }.eachCount()
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        if (!isMe) {
                            AvatarBubble(
                                initialsName = partner?.displayName,
                                email = partner?.email,
                                avatarBytes = partner?.avatarBytes,
                                size = 32.dp
                            )
                            Spacer(Modifier.width(6.dp))
                        } else {
                            Spacer(Modifier.width(38.dp))
                        }

                        Column(horizontalAlignment = if (isMe) Alignment.End else Alignment.Start) {

                            if (msg.replyPreview != null) {
                                Box(
                                    modifier = Modifier
                                        .padding(bottom = 2.dp)
                                        .background(
                                            Color(0xFF000000).copy(alpha = 0.3f),
                                            RoundedCornerShape(12.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = msg.replyPreview,
                                        color = Color.White.copy(alpha = 0.8f),
                                        style = MaterialTheme.typography.bodySmall,
                                        maxLines = 1
                                    )
                                }
                            }

                            Surface(
                                color = if (isMe) Color(0xFF1877F2) else Color(0xFF3A3B3C),
                                shape = if (isMe)
                                    RoundedCornerShape(20.dp, 4.dp, 20.dp, 20.dp)
                                else
                                    RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp),
                                shadowElevation = 2.dp,
                                modifier = Modifier
                                    .offset { IntOffset(dragOffset.roundToInt(), 0) }
                                    .pointerInput(msg.id) {
                                        detectHorizontalDragGestures(
                                            onHorizontalDrag = { _, delta ->
                                                dragOffset = (dragOffset + delta).coerceIn(-maxDragPx, maxDragPx)
                                            },
                                            onDragEnd = {
                                                if (abs(dragOffset) > maxDragPx * 0.6f) viewModel.startReply(msg)
                                                dragOffset = 0f
                                            },
                                            onDragCancel = { dragOffset = 0f }
                                        )
                                    }
                                    .combinedClickable(
                                        onClick = {},
                                        onLongClick = {
                                            reactionTargetId = if (reactionTargetId == msg.id) null else msg.id
                                        }
                                    )
                            ) {
                                if (msg.imageBytes != null) {
                                    val bitmap = remember(msg.id, msg.imageBytes) {
                                        try {
                                            BitmapFactory.decodeByteArray(msg.imageBytes, 0, msg.imageBytes.size)
                                        } catch (_: Exception) {
                                            null
                                        }
                                    }
                                    Column(
                                        modifier = Modifier
                                            .padding(4.dp)
                                            .widthIn(max = 260.dp)
                                    ) {
                                        if (bitmap != null) {
                                            Image(
                                                bitmap = bitmap.asImageBitmap(),
                                                contentDescription = "Image",
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .heightIn(max = 280.dp)
                                                    .clip(RoundedCornerShape(16.dp)),
                                                contentScale = ContentScale.Crop
                                            )
                                        }
                                        if (msg.text.isNotBlank()) {
                                            Spacer(Modifier.height(4.dp))
                                            Text(text = msg.text, color = Color.White)
                                        }
                                    }
                                } else {
                                    Text(
                                        text = msg.text,
                                        color = Color.White,
                                        modifier = Modifier
                                            .padding(horizontal = 12.dp, vertical = 8.dp)
                                            .widthIn(max = 260.dp)
                                    )
                                }
                            }

                            // Reaction summary
                            if (reactionCounts.isNotEmpty()) {
                                Spacer(Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.25f), RoundedCornerShape(12.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    reactionCounts.forEach { (emoji, count) ->
                                        Text(
                                            text = if (count > 1) "$emoji $count" else emoji,
                                            color = Color.White,
                                            fontSize = 12.sp,
                                            modifier = Modifier.padding(end = 8.dp)
                                        )
                                    }
                                }
                            }

                            // Reaction picker
                            if (reactionTargetId == msg.id) {
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier
                                        .background(Color.Black.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                                        .padding(horizontal = 10.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    reactionEmojis.forEach { emoji ->
                                        Box(
                                            modifier = Modifier
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                                .clip(CircleShape)
                                                .clickable {
                                                    viewModel.toggleReaction(partnerId, msg.id, emoji)
                                                    reactionTargetId = null
                                                }
                                                .padding(horizontal = 6.dp, vertical = 4.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(text = emoji, fontSize = 18.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // ===== REPLY BAR =====
            if (replyingTo != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF000000).copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            text = if (replyingTo.fromId == myId) "Trả lời chính bạn"
                            else "Trả lời ${partner?.displayName ?: ""}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = replyingTo.text,
                            color = Color.White.copy(alpha = 0.8f),
                            maxLines = 1,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    IconButton(onClick = { viewModel.cancelReply() }) {
                        Icon(Icons.Filled.Close, contentDescription = "Hủy reply", tint = Color.White)
                    }
                }
            }

            // ===== INPUT =====
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF242526).copy(alpha = 0.9f))
                    .padding(horizontal = 8.dp, vertical = 6.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = {}) { Icon(Icons.Default.Add, contentDescription = "More", tint = Color.White) }
                    IconButton(onClick = {}) { Icon(Icons.Default.PhotoCamera, contentDescription = "Camera", tint = Color.White) }
                    IconButton(onClick = { pickImageLauncher.launch("image/*") }) {
                        Icon(Icons.Default.Image, contentDescription = "Image", tint = Color.White)
                    }
                    IconButton(onClick = {}) { Icon(Icons.Default.Mic, contentDescription = "Mic", tint = Color.White) }
                }

                Spacer(Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    TextField(
                        value = text,
                        onValueChange = { text = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Aa") },
                        singleLine = true,
                        shape = RoundedCornerShape(50),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Black.copy(alpha = 0.85f),
                            unfocusedContainerColor = Color.Black.copy(alpha = 0.85f),
                            cursorColor = Color.White,
                            focusedIndicatorColor = Color.Transparent,
                            unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White,
                            focusedPlaceholderColor = Color.Gray,
                            unfocusedPlaceholderColor = Color.Gray
                        )
                    )

                    Spacer(Modifier.width(6.dp))

                    IconButton(
                        onClick = {
                            val sendText = text
                            viewModel.sendMessage(partnerId, sendText)
                            text = ""

                            // Kéo xuống cuối ngay lập tức cho mượt
                            scope.launch {
                                if (messages.isNotEmpty()) {
                                    listState.animateScrollToItem(messages.size - 1)
                                }
                            }
                        },
                        enabled = text.isNotBlank()
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = if (text.isNotBlank()) Color(0xFF2E89FF) else Color.Gray
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AvatarBubble(
    initialsName: String?,
    email: String?,
    avatarBytes: ByteArray?,
    size: Dp
) {
    val initials = initialsName?.firstOrNull()?.uppercase()
        ?: email?.firstOrNull()?.uppercase()
        ?: "U"

    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(Color(0xFF222222)),
        contentAlignment = Alignment.Center
    ) {
        if (avatarBytes != null) {
            val bitmap = remember(avatarBytes) {
                try {
                    BitmapFactory.decodeByteArray(avatarBytes, 0, avatarBytes.size)
                } catch (_: Exception) {
                    null
                }
            }
            if (bitmap != null) {
                Image(
                    bitmap = bitmap.asImageBitmap(),
                    contentDescription = "Avatar",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Text(text = initials, color = Color.White, fontWeight = FontWeight.Bold)
            }
        } else {
            Text(text = initials, color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}
