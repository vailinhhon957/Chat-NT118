package com.example.chat_compose.model

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.chat_compose.data.CallRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CallViewModel(
    private val repo: CallRepository = CallRepository()
) : ViewModel() {

    // idle | ringing | accepted | ended
    private val _callState = MutableStateFlow("idle")
    val callState: StateFlow<String> = _callState

    private val _callId = MutableStateFlow<String?>(null)
    val callId: StateFlow<String?> = _callId

    private val _partnerUid = MutableStateFlow<String?>(null)
    val partnerUid: StateFlow<String?> = _partnerUid

    private var incomingJob: Job? = null
    private var callDocJob: Job? = null

    /**
     * Lắng nghe incoming bằng CallRepository.listenIncomingCallsForUser()
     * => Flow<IncomingCall?>
     */
    fun startIncomingListener() {
        val myUid = repo.currentUid() ?: return
        if (incomingJob?.isActive == true) return

        incomingJob = viewModelScope.launch {
            repo.listenIncomingCallsForUser(myUid).collect { incoming ->
                if (incoming == null) return@collect

                // nếu đang có call thì bỏ qua (tuỳ bạn)
                if (_callId.value != null && _callState.value != "idle") return@collect

                _callId.value = incoming.id
                _partnerUid.value = incoming.callerId
                _callState.value = "ringing"

                observeCallDoc(incoming.id)
            }
        }
    }

    // Bên gọi
    fun startCall(partnerId: String) {
        viewModelScope.launch {
            try {
                _callState.value = "ringing"
                _partnerUid.value = partnerId

                val id = repo.startOutgoingCall(partnerId)
                _callId.value = id

                observeCallDoc(id)
            } catch (e: Exception) {
                Log.e("CALL", "startCall failed", e)
                resetCall()
            }
        }
    }

    fun acceptIncoming() {
        val id = _callId.value ?: return
        viewModelScope.launch {
            runCatching { repo.acceptCall(id) }
                .onFailure { Log.e("CALL", "acceptIncoming failed", it) }
        }
    }

    fun rejectIncoming() {
        val id = _callId.value ?: return
        viewModelScope.launch {
            runCatching { repo.rejectCall(id) }
                .onFailure { Log.e("CALL", "rejectIncoming failed", it) }
            resetCall()
        }
    }

    fun hangup() {
        val id = _callId.value ?: return
        viewModelScope.launch {
            runCatching { repo.endCall(id) }
                .onFailure { Log.e("CALL", "hangup failed", it) }
            resetCall()
        }
    }

    private fun observeCallDoc(callId: String) {
        callDocJob?.cancel()
        callDocJob = viewModelScope.launch {
            repo.listenCallDoc(callId).collect { data ->
                val status = data["status"] as? String ?: return@collect
                _callState.value = status

                // auto partner (from/to)
                val myUid = repo.currentUid()
                val from = data["from"] as? String
                val to = data["to"] as? String
                if (myUid != null && from != null && to != null) {
                    _partnerUid.value = if (myUid == from) to else from
                }

                if (status == "ended") {
                    resetCall()
                }
            }
        }
    }

    private fun resetCall() {
        callDocJob?.cancel()
        callDocJob = null
        _callId.value = null
        _partnerUid.value = null
        _callState.value = "idle"
    }

    override fun onCleared() {
        incomingJob?.cancel()
        callDocJob?.cancel()
        super.onCleared()
    }
}
