package com.example.chat_compose

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.chat_compose.data.ChatRepository
import com.example.chat_compose.model.ChatUser
import com.example.chat_compose.model.Message
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

class ChatViewModel(
    private val repo: ChatRepository = ChatRepository()
) : ViewModel() {

    // ============= DANH SÁCH BẠN BÈ (HomeScreen dùng) =============
    var friends by mutableStateOf<List<ChatUser>>(emptyList())
        private set

    private var friendsJob: Job? = null

    fun listenFriends() {
        friendsJob?.cancel()
        friendsJob = viewModelScope.launch {
            val myUid = repo.currentUserId() ?: return@launch
            repo.listenFriends(myUid).collect { list ->
                friends = list
            }
        }
    }

    // ================== STATE CHAT ==================
    var messages by mutableStateOf<List<Message>>(emptyList())
        private set

    var partnerUser by mutableStateOf<ChatUser?>(null)
        private set

    var replyingTo by mutableStateOf<Message?>(null)
        private set

    private var msgJob: Job? = null
    private var partnerJob: Job? = null

    // ===== ONLINE STATUS (MainActivity dùng) =====
    suspend fun updateOnlineStatus(isOnline: Boolean) {
        repo.updateOnlineStatus(isOnline)
    }

    // ===== LOAD / LISTEN PARTNER =====
    fun listenPartner(uid: String) {
        partnerJob?.cancel()
        partnerJob = viewModelScope.launch {
            repo.listenUser(uid).collect { user ->
                partnerUser = user
            }
        }
    }

    // ===== LISTEN MESSAGE VỚI 1 NGƯỜI =====
    fun listenMessages(partnerId: String) {
        msgJob?.cancel()
        msgJob = viewModelScope.launch {
            repo.listenMessages(partnerId).collect { list ->
                messages = list
            }
        }
    }

    // ===== REPLY =====
    fun startReply(msg: Message) {
        replyingTo = msg
    }

    fun cancelReply() {
        replyingTo = null
    }

    // ===== GỬI TIN NHẮN (QUAN TRỌNG: Đã sửa logic AI ở đây) =====
    fun sendMessage(partnerId: String, text: String) {
        if (text.isBlank()) return
        val reply = replyingTo

        viewModelScope.launch {
            // [SỬA LẠI] Kiểm tra ID người nhận
            if (partnerId == ChatRepository.AI_BOT_ID) {
                // Nếu là Bot -> Gọi hàm AI (Gửi tin User -> Gọi Gemini -> Gửi tin Bot)
                repo.sendAiMessage(text = text.trim(), replyingTo = reply)
            } else {
                // Nếu là người thường -> Gửi bình thường
                repo.sendMessage(partnerId, text.trim(), replyingTo = reply)
            }
        }
        replyingTo = null
    }

    // ===== GỬI ẢNH (imageUrl) =====
    fun sendImageMessage(toId: String, imageBytes: ByteArray) {
        val reply = replyingTo
        viewModelScope.launch {
            repo.sendImageMessage(
                partnerId = toId,
                bytes = imageBytes,
                text = "",
                replyingTo = reply
            )
            replyingTo = null
        }
    }

    // ===== REACT EMOJI =====
    fun toggleReaction(partnerId: String, messageId: String, emoji: String) {
        viewModelScope.launch {
            repo.toggleReaction(
                partnerId = partnerId,
                msgId = messageId,
                emoji = emoji
            )
        }
    }
}