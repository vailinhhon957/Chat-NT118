package com.example.chat_compose.push

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.chat_compose.MainActivity
import com.example.chat_compose.R
import kotlin.random.Random

object NotificationHelper {

    const val CHANNEL_ID = "chat_channel_id"
    const val CHANNEL_NAME = "Chat Notifications"

    // Key này PHẢI KHỚP với key bạn dùng trong MainActivity
    const val EXTRA_OPEN_CHAT_PARTNER_ID = "open_chat_partner_id"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Thông báo tin nhắn mới"
            }
            val manager = context.getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    fun showMessage(
        context: Context,
        partnerId: String,
        title: String,
        body: String,
        largeIcon: Bitmap? = null
    ) {
        // 1. Tạo Intent trỏ về MainActivity
        val intent = Intent(context, MainActivity::class.java).apply {
            // Cờ này giúp mở lại app mượt mà
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            // QUAN TRỌNG: Gắn ID người gửi vào Intent để MainActivity đọc
            putExtra(EXTRA_OPEN_CHAT_PARTNER_ID, partnerId)
        }

        // 2. Tạo PendingIntent (để Android kích hoạt khi bấm thông báo)
        val pendingIntent = PendingIntent.getActivity(
            context,
            partnerId.hashCode(), // RequestCode khác nhau để không bị ghi đè Intent
            intent,
            // Flag Immutable là bắt buộc trên Android 12+
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        // 3. Xây dựng giao diện thông báo
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_foreground) // Thay bằng icon app của bạn (vd: R.drawable.ic_message)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true) // Bấm xong tự biến mất
            .setContentIntent(pendingIntent) // Gắn hành động click

        if (largeIcon != null) {
            builder.setLargeIcon(largeIcon)
        }

        // 4. Hiển thị
        if (androidx.core.content.ContextCompat.checkSelfPermission(
                context,
                android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            NotificationManagerCompat.from(context).notify(Random.nextInt(), builder.build())
        }
    }
}